package org.example.automation.pepperfry.utils;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class CommonMethods {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected WaitUtils waitUtils;
    protected JavascriptExecutor jsExecutor;

    public CommonMethods(WebDriver driver) {
        this.driver = driver;
        int explicitWait = ConfigReader.getExplicitWait();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(explicitWait));
        this.waitUtils = new WaitUtils(driver);
        this.jsExecutor = (JavascriptExecutor) driver;
    }

    public void handlePopup() {
        try {
            List<WebElement> closeBtn = driver.findElements(By.xpath("//a[@class='close-modal']"));
            if (!closeBtn.isEmpty() && closeBtn.get(0).isDisplayed()) {
                System.out.println("Popup detected, closing...");
                safeClick(closeBtn.get(0));
            }
        } catch (Exception e) {
       }
    }

    public void clickElement(By locator) {
        try {
            WebElement element = waitUtils.waitForElementVisible(locator);
            
            element = waitUtils.waitForElementClickable(locator);
            
            try {
                element.click();
                System.out.println("Successfully clicked element: " + locator);
            } catch (ElementClickInterceptedException e) {

                System.out.println("Element click intercepted, trying JavaScript click: " + locator);
                scrollToElement(element);
                try {
                    Thread.sleep(500);

                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
                jsExecutor.executeScript("arguments[0].click();", element);
            }
            catch (StaleElementReferenceException e) {
                System.out.println("Stale element, retrying: " + locator);
                element = waitUtils.waitForElementClickable(locator);
                element.click();
            }
        } catch (TimeoutException e) {
            System.err.println("Element not found or not clickable: " + locator);
            throw new TimeoutException("Failed to click element: " + locator, e);
        }
        catch (Exception e) {
            System.err.println("Unexpected error clicking element: " + locator + " - " + e.getMessage());

            try {
                WebElement element = driver.findElement(locator);
                jsExecutor.executeScript("arguments[0].click();", element);
            } catch (Exception ex) {
                throw new RuntimeException("Failed to click element after all retries: " + locator, ex);
            }
        }
    }

    public void safeClick(WebElement element) {
        try {
            WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(5));
            shortWait.until(ExpectedConditions.elementToBeClickable(element));
            element.click();
        }
        catch (ElementClickInterceptedException e) {
            scrollToElement(element);
            jsExecutor.executeScript("arguments[0].click();", element);
        } catch (Exception e) {
            jsExecutor.executeScript("arguments[0].click();", element);
        }
    }

    public void scrollToElement(WebElement el) {
        try {
            jsExecutor.executeScript("arguments[0].scrollIntoView({block:'center', behavior:'smooth'});", el);
            // Small wait after scroll
            try {
                Thread.sleep(300);
            }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        } catch (Exception e) {
            System.err.println("Error scrolling to element: " + e.getMessage());
        }
    }

    public void scrollToElement(By locator) {
        try {
            WebElement element = waitUtils.waitForElementPresent(locator);
            scrollToElement(element);
        } catch (Exception e) {
            System.err.println("Error scrolling to element by locator: " + locator);
        }
    }

    public String getText(By locator) {
        try {
            WebElement element = waitUtils.waitForElementVisible(locator);
            return element.getText();
        }
        catch (Exception e) {
            System.err.println("Error getting text from element: " + locator);
            throw new RuntimeException("Failed to get text from element: " + locator, e);
        }
    }

    public void clickElementWithRetry(By locator, int maxRetries) {
        for (int i = 0; i < maxRetries; i++) {
            try {
                clickElement(locator);
                return;
            } catch (Exception e) {
                if (i == maxRetries - 1) {
                    throw new RuntimeException("Failed to click element after " + maxRetries + " retries: " + locator, e);
                }
                System.out.println("Retry " + (i + 1) + " for clicking element: " + locator);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}