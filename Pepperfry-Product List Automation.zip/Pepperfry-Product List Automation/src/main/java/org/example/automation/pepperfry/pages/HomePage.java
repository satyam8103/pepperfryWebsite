package org.example.automation.pepperfry.pages;

import org.example.automation.pepperfry.utils.CommonMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class HomePage extends CommonMethods {

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public void goToSetteesAndBenches() {
        try {
            handlePopup();
            waitUtils.waitForPageLoad();
            By furnitureLocator = By.xpath("//a[normalize-space()='Furniture']");
            WebElement furniture = waitUtils.waitForElementClickable(furnitureLocator);
            new Actions(driver).moveToElement(furniture).pause(java.time.Duration.ofMillis(500)).perform();

            By setteesBenchesLocator = By.xpath(
                    "//a[contains(text(),'Settees') and contains(text(),'Benches')] | " +
                    "//a[normalize-space()='Settees & Benches']"
            );
            clickElementWithRetry(setteesBenchesLocator, 3);
            
            waitUtils.waitForPageLoad();
        }
        catch (Exception e) {
            System.err.println("Error navigating to Settees & Benches: " + e.getMessage());
            throw new RuntimeException("Failed to navigate to Settees & Benches", e);
        }
    }
}