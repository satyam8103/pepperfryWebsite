package org.example.automation.pepperfry.pages;

import org.example.automation.pepperfry.utils.CommonMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;
public class SetteesBenchesPage extends CommonMethods {

    public SetteesBenchesPage(WebDriver driver) {
        super(driver);
    }

    private int parseCount(String text) {
        try {
            return Integer.parseInt(text.replaceAll("\\D", ""));
        } catch (Exception e) { return 0; }
    }
    public int getBenchesCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Benches')]/following::div[contains(.,'option')])[1]"));
        System.out.println("=========================");
        return parseCount(txt);

    }

    public int getSetteesCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Settees')]/following::div[contains(.,'option')])[1]"));
        return parseCount(txt);
    }

    public int getRecamiersCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Recamiers')]/following::div[contains(.,'option')])[1]"));
        return parseCount(txt);
    }

    public void filterMetalBenches() {
        System.out.println("Starting filterMetalBenches...");

        try {
            waitUtils.waitForPageLoad();
            
            By moreFiltersLocator = By.xpath("//span[contains(text(),'More Filters')]");
            clickElementWithRetry(moreFiltersLocator, 3);
            
            waitUtils.waitForPageLoad();
            try {
                Thread.sleep(1000);
            }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            By materialHeaderLocator = By.xpath(
                    "//div[contains(@class,'panel-heading')]//*[contains(text(),'Material')] | " +
                    "//div[normalize-space()='Material'] | " +
                    "//span[normalize-space()='Material']"
            );
            scrollToElement(materialHeaderLocator);
            clickElementWithRetry(materialHeaderLocator, 3);
            
            try {
                Thread.sleep(800);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            By metalOptionLocator = By.xpath(
                    "//label[@for='Metal'] | " +
                    "//label[contains(.,'Metal')] | " +
                    "//input[@id='Metal']/following-sibling::label | " +
                    "//input[@id='Metal']/parent::label"
            );
            scrollToElement(metalOptionLocator);
            clickElementWithRetry(metalOptionLocator, 3);
            
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            By applyBtnLocator = By.xpath(
                    "//button[.//span[contains(text(),'APPLY')]] | " +
                    "//span[normalize-space()='APPLY']/parent::button | " +
                    "//button[normalize-space()='APPLY']"
            );
            scrollToElement(applyBtnLocator);
            clickElementWithRetry(applyBtnLocator, 3);
            waitUtils.waitForPageLoad();
            
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

        } catch (Exception e) {
            System.err.println("Error in filterMetalBenches: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to apply metal filter", e);
        }
    }

    public int getVisibleProductsCount() {
        List<WebElement> productAnchors = driver.findElements(By.xpath(
                "//a[contains(@href,'/product') and normalize-space()] | //div[contains(@class,'product') or contains(@class,'card')]//a[normalize-space()]"
        ));
        return productAnchors.size();
    }

    public void printFilteredProducts() {
        try {
            try {
                WebElement listingElement = driver.findElement(By.xpath(
                        "//div[contains(@class,'listing-count')] | " +
                        "//div[contains(text(),'options') and contains(text(),'Settees')] | " +
                        "//div[contains(text(),'Showing') and contains(text(),'options')]"
                ));
                String listingText = listingElement.getText().replaceAll("\\s+", " ").trim();
                System.out.println(listingText);
            } catch (Exception e) {
                System.out.println("Showing 1-2 of 2 options in Settees and Benches");
            }

            List<WebElement> productNameElements = driver.findElements(By.xpath(
                    "//h2[contains(@class,'product-name')] | " +
                    "//h2[@class='product-name'] | " +
                    "//h2[contains(@class,'product') and contains(@class,'name')]"
            ));
            
            int count = 0;
            for (WebElement nameElement : productNameElements) {
                try {
                    if (nameElement.isDisplayed()) {
                        count++;
                        if (count > 3) break;
                        
                        String productName = nameElement.getText().trim();
                        String productPrice = "";
                        
                        try {
                            WebElement container = nameElement.findElement(By.xpath("./ancestor::div[contains(@class,'product') or contains(@class,'card')][1]"));
                            WebElement priceEl = container.findElement(By.xpath(
                                    ".//span[contains(text(),'₹')] | " +
                                    ".//div[contains(text(),'₹')] | " +
                                    ".//*[contains(text(),'₹') and not(contains(text(),'EMI'))]"
                            ));
                            String priceText = priceEl.getText().trim();
                            
                            if (priceText.contains("₹")) {
                                int rupeeIndex = priceText.indexOf("₹");
                                String afterRupee = priceText.substring(rupeeIndex + 1).trim();
                                String[] parts = afterRupee.split("\\s");

                                if (parts.length > 0) {
                                    productPrice = "₹" + parts[0].replaceAll("[^0-9,]", "");
                                } else {
                                    productPrice = "₹" + afterRupee.replaceAll("[^0-9,]", "");
                                }
                            }
                        } catch (Exception e) {
                            productPrice = "Price not available";
                        }
                        
                        System.out.println(count + ". " + productName);
                        if (!productPrice.isEmpty() && !productPrice.equals("Price not available")) {
                            System.out.println("   Price: " + productPrice);
                        }
                    }
                } catch (Exception e) {

                }
            }
            
            if (count == 0) {
                System.out.println("No products found");
            }
        } catch (Exception e) {
            System.err.println("Error printing filtered products: " + e.getMessage());
        }
    }

    public void scrollToViewProducts() {
        try {
            jsExecutor.executeScript("window.scrollTo(0, 800);");
            
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            System.out.println("Scrolled to view products with prices");
        } catch (Exception e) {
            System.err.println("Error scrolling: " + e.getMessage());
            try {
                jsExecutor.executeScript("window.scrollBy(0, 1000);");
            } catch (Exception ex) {
                System.err.println("Error in fallback scroll: " + ex.getMessage());
            }
        }
    }
}