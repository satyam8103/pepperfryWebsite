package org.automation.pepperfry.tests;

import org.example.automation.pepperfry.base.BaseClass;
import org.example.automation.pepperfry.pages.HomePage;
import org.example.automation.pepperfry.utils.ScreenshotUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC01_Validate_Title extends BaseClass {

    @Test
    public void validateTitle() throws Exception {
        HomePage home = new HomePage(driver);
        String title = home.getTitle();
        System.out.println("Page Title: " + title);
        String expected = "Buy Furniture & Home Decor Online – Up to 70% Off at Best Prices in India ";
        Assert.assertTrue(title.contains("Furniture") || title.contains("Shopping"),
                "Title validation failed!");
        ScreenshotUtils.takeScreenshot(driver, "Title_Validation");

    }
}