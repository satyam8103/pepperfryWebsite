package org.automation.pepperfry.tests;

import org.example.automation.pepperfry.base.BaseClass;
import org.example.automation.pepperfry.pages.HomePage;
import org.example.automation.pepperfry.pages.SetteesBenchesPage;
import org.example.automation.pepperfry.utils.ScreenshotUtils;
import org.testng.annotations.Test;

public class TC04_Screenshot_And_Count extends BaseClass {
    @Test
    public void screenshotAndCount() throws Exception {
        HomePage home = new HomePage(driver);
        home.goToSetteesAndBenches();

        SetteesBenchesPage page = new SetteesBenchesPage(driver);
        
        page.filterMetalBenches();
        
        try {
            Thread.sleep(4000);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        page.scrollToViewProducts();

        try {
            Thread.sleep(1500);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        System.out.println("\n========== PRODUCTS AFTER METAL FILTER ==========");
        page.printFilteredProducts();
        System.out.println("==================================================\n");
        System.out.println("Capturing screenshot...");

        ScreenshotUtils.takeScreenshot(driver, "After_Filter_Metal_Benches_Result");

        System.out.println("Screenshot captured successfully: After_Filter_Metal_Benches_Result.png");

    }
}