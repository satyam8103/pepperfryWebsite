package org.automation.pepperfry.tests;

import org.example.automation.pepperfry.base.BaseClass;
import org.example.automation.pepperfry.pages.HomePage;
import org.example.automation.pepperfry.pages.SetteesBenchesPage;
import org.example.automation.pepperfry.utils.ScreenshotUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC02_Count_Furniture extends BaseClass {

    @Test
    public void countFurniture() throws Exception {
        HomePage home = new HomePage(driver);
        home.goToSetteesAndBenches();

        SetteesBenchesPage page = new SetteesBenchesPage(driver);

        System.out.println("=== Furniture Category Counts ===");
        System.out.println("Benches Count: " + page.getBenchesCount());
        System.out.println("Settees Count: " + page.getSetteesCount());
        System.out.println("Recamiers Count: " + page.getRecamiersCount());

        // No need of assertions here
        int actualBenchCount = page.getBenchesCount();
        int expectedBenchCount = 115;

        int actualSetteesCount = page.getSetteesCount();
        int expectedSetteesCount = 14;

        int actualRecamiersCount = page.getRecamiersCount();
        int expectedRecamiersCount = 22;

        Assert.assertEquals(actualBenchCount,expectedBenchCount,"wrong output results");
        Assert.assertEquals(actualSetteesCount,expectedSetteesCount,"wrong output results");
        Assert.assertEquals(actualRecamiersCount,expectedRecamiersCount,"wrong output results");
        ScreenshotUtils.takeScreenshot(driver, "count_furniture");

//
    }
}