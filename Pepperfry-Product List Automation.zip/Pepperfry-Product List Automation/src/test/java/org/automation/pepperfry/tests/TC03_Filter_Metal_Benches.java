package org.automation.pepperfry.tests;

import org.example.automation.pepperfry.base.BaseClass;
import org.example.automation.pepperfry.pages.HomePage;
import org.example.automation.pepperfry.pages.SetteesBenchesPage;
import org.example.automation.pepperfry.utils.ScreenshotUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC03_Filter_Metal_Benches extends BaseClass {

    @Test
    public void filterMetal() throws Exception {
        HomePage home = new HomePage(driver);
        home.goToSetteesAndBenches();

        SetteesBenchesPage page = new SetteesBenchesPage(driver);
        page.filterMetalBenches();

        int count = page.getVisibleProductsCount();
        System.out.println("=== Filter Results ===");
        System.out.println("Metal Benches Visible: " + count);

        int actual = count;
        int expected = 18;

        Assert.assertEquals(actual,expected,"Not the correct result");
        ScreenshotUtils.takeScreenshot(driver, "Before_filter_metal_benches");

    }
}