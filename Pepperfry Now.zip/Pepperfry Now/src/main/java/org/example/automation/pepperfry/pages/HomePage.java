package org.example.automation.pepperfry.pages;

import org.example.automation.pepperfry.utils.CommonMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class HomePage extends CommonMethods {

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public void goToSetteesAndBenches() throws InterruptedException {
        handlePopup();

        WebElement furniture = driver.findElement(By.xpath("//a[normalize-space()='Furniture']"));
        new Actions(driver).moveToElement(furniture).pause(java.time.Duration.ofMillis(500)).perform();

        clickElement(By.xpath("//a[contains(text(),'Settees') and contains(text(),'Benches')] | //a[normalize-space()='Settees & Benches']"));
    }
}