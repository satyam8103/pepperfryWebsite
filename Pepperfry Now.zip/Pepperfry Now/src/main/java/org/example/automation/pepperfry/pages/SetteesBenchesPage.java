//package org.example.automation.pepperfry.pages;
//
//import org.example.automation.pepperfry.utils.CommonMethods;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//
//import java.util.List;
//
//public class SetteesBenchesPage extends CommonMethods {
//
//    public SetteesBenchesPage(WebDriver driver) {
//        super(driver);
//    }
//
//    private int parseCount(String text) {
//        try {
//            return Integer.parseInt(text.replaceAll("\\D", ""));
//        } catch (Exception e) { return 0; }
//    }
//
//    public int getBenchesCount() {
//        String txt = getText(By.xpath("(//div[contains(text(),'Benches')]/following::div[contains(.,'option')])[1]"));
//        return parseCount(txt);
//    }
//
//    public int getSetteesCount() {
//        String txt = getText(By.xpath("(//div[contains(text(),'Settees')]/following::div[contains(.,'option')])[1]"));
//        return parseCount(txt);
//    }
//
//    public int getRecamiersCount() {
//        String txt = getText(By.xpath("(//div[contains(text(),'Recamiers')]/following::div[contains(.,'option')])[1]"));
//        return parseCount(txt);
//    }
//
//    // Filter Logic (More Filters -> Material -> Metal -> Apply)
//    public void filterMetalBenches() throws InterruptedException {
//        Thread.sleep(2000);
//
//
//        // 1. Open Filter Drawer
//        clickElement(By.xpath("//div[contains(@class,'filter')]//span[contains(text(),'Material') or contains(text(),'Filters')] | //span[contains(@class, 'filter')]"));
//        Thread.sleep(1500);
//
//        System.out.println("running here");
////        clickElement(By.xpath("(//div[normalize-space()='Material'] | //span[normalize-space()='Material'])[1]"));
////            WebElement material = driver.findElement(By.linkText(" More Filters "));
////            material.click();
//
//        By moreFiltersLocator = By.xpath("//span[normalize-space()='More Filters']");
//
//        clickElement(moreFiltersLocator);
//
//        Thread.sleep(1500);
//        System.out.println("filter functionality working");
//
//        WebElement metal = driver.findElement(By.xpath("//label[@for='Metal'] | //label[contains(.,'Metal')]"));
//        scrollToElement(metal);
//        clickElement(By.xpath("//label[@for='Metal'] | //label[contains(.,'Metal')]"));
//
//        WebElement apply = driver.findElement(By.xpath("//button[.//span[normalize-space()='APPLY']] | //span[normalize-space()='APPLY']"));
//        scrollToElement(apply);
//        apply.click();
//
//        Thread.sleep(3000); // Grid reload wait
//    }
//
//    public int getVisibleProductsCount() {
//        List<WebElement> list = driver.findElements(By.xpath("//a[contains(@href,'/product') and normalize-space()]"));
//        return list.size();
//    }
//}



package org.example.automation.pepperfry.pages;

import org.example.automation.pepperfry.utils.CommonMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class SetteesBenchesPage extends CommonMethods {

    public SetteesBenchesPage(WebDriver driver) {
        super(driver);
    }

    private int parseCount(String text) {
        try {
            return Integer.parseInt(text.replaceAll("\\D", ""));
        } catch (Exception e) { return 0; }
    }

    // === Counts Methods (Inko change nahi kiya, ye sahi the) ===
    public int getBenchesCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Benches')]/following::div[contains(.,'option')])[1]"));
        return parseCount(txt);
    }

    public int getSetteesCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Settees')]/following::div[contains(.,'option')])[1]"));
        return parseCount(txt);
    }

    public int getRecamiersCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Recamiers')]/following::div[contains(.,'option')])[1]"));
        return parseCount(txt);
    }

    // === Updated Filter Logic (Based on your working Single File Code) ===
    public void filterMetalBenches() throws InterruptedException {

        // 1. Click "More Filters" using Absolute XPath (Jo working hai)
        WebElement moreFiltersContainer = driver.findElement(
                By.xpath("/html/body/app-root/main/app-category/pf-clip/div/div[1]/div[3]/pf-clip-filter/div[1]/div/div/div/div[1]/span[5]/span[3]")
        );
        moreFiltersContainer.click();
        System.out.println("More Filters clicked (Absolute XPath used)");
        Thread.sleep(3000); // Wait for drawer

        // 2. Click "Material" Header inside Drawer
        WebElement materialHeader = driver.findElement(By.xpath(
                "(//div[normalize-space()='Material'] | //span[normalize-space()='Material'] | //button[normalize-space()='Material'])[1]"
        ));
        // JS Scroll use kar rahe hain jaisa tumne diya
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", materialHeader);
        materialHeader.click();
        Thread.sleep(1200);

        // 3. Select "Metal" Option
        WebElement metalOption = driver.findElement(By.xpath(
                "//label[@for='Metal'] | //label[contains(.,'Metal')] | //span[normalize-space()='Metal']"
        ));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", metalOption);
        metalOption.click();
        Thread.sleep(1000);

        // 4. Click "APPLY" Button
        WebElement applyBtn = driver.findElement(By.xpath(
                "//button[.//span[normalize-space()='APPLY']] | //span[normalize-space()='APPLY']"
        ));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", applyBtn);
        applyBtn.click();

        System.out.println("Filter Applied. Waiting for grid refresh...");
        Thread.sleep(4000); // Grid refresh wait
    }

    // === Count Visible Products (Your Logic) ===
    public int getVisibleProductsCount() {
        List<WebElement> productAnchors = driver.findElements(By.xpath(
                "//a[contains(@href,'/product') and normalize-space()] | //div[contains(@class,'product') or contains(@class,'card')]//a[normalize-space()]"
        ));
        return productAnchors.size();
    }
}