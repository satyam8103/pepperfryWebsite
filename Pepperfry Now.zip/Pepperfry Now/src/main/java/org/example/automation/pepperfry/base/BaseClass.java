package org.example.automation.pepperfry.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import java.time.Duration;
import java.util.Arrays;

public class BaseClass {

    protected WebDriver driver;

    @BeforeMethod
    @Parameters("browser")
    public void setUp(@Optional("chrome") String browser) {

        if (browser.equalsIgnoreCase("firefox")) {
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            driver = new EdgeDriver();
        } else {
            // Chrome Options setup to block popups
            ChromeOptions options = new ChromeOptions();

            // 1. Notification Allow/Block popup ko disable karta hai
            options.addArguments("--disable-notifications");

            // 2. Automation control bar (Chrome is being controlled by...) ko hide karta hai
            options.setExperimentalOption("excludeSwitches", Arrays.asList("enable-automation"));

            // 3. Browser extensions ko disable karta hai (jo ads la sakte hain)
            options.addArguments("--disable-extensions");

            // 4. Page load hone ka wait strategy (Normal = wait until load event)
            // options.setPageLoadStrategy(org.openqa.selenium.PageLoadStrategy.NORMAL);

            // 5. Window maximize arguments
            options.addArguments("--start-maximized");

            // Initialize driver with options
            driver = new ChromeDriver(options);
        }

        // Implicit wait har element ke liye
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // URL Open
        driver.get("https://www.pepperfry.com/");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}