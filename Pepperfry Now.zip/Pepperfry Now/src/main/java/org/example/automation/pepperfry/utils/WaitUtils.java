package org.example.automation.pepperfry.utils;

public class WaitUtils {
}
