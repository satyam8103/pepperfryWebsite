package org.automation.pepperfry.tests;

import org.example.automation.pepperfry.base.BaseClass;
import org.example.automation.pepperfry.pages.HomePage;
import org.example.automation.pepperfry.pages.SetteesBenchesPage;
import org.example.automation.pepperfry.utils.ScreenshotUtils;
import org.testng.annotations.Test;

public class TC04_Screenshot_And_Count extends BaseClass {
    @Test
    public void screenshotAndCount() throws Exception {
        HomePage home = new HomePage(driver);
        home.goToSetteesAndBenches();

        SetteesBenchesPage page = new SetteesBenchesPage(driver);
        
        // Apply Metal Filter
        System.out.println("Applying Metal Filter...");
        page.filterMetalBenches();
        
        // Wait for filter results to load
        System.out.println("Waiting for filter results to load...");
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Scroll to view products
        System.out.println("Scrolling to view products...");
        page.scrollToViewProducts();
        
        // Wait a bit after scroll
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Print the 2 products after filter
        System.out.println("\n========== PRODUCTS AFTER METAL FILTER ==========");
        page.printFilteredProducts();
        System.out.println("==================================================\n");
        
        // Take Screenshot
        System.out.println("Capturing screenshot...");
        ScreenshotUtils.takeScreenshot(driver, "Metal_Benches_Result");
        System.out.println("Screenshot captured successfully: Metal_Benches_Result.png");
        
        // Print total count
//        int totalCount = page.getVisibleProductsCount();
//        System.out.println("\nTotal Products After Metal Filter: " + totalCount);
    }
}