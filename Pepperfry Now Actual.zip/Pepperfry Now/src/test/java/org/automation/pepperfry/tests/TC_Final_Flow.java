//package org.automation.pepperfry.tests;
//
//import org.example.automation.pepperfry.base.BaseClass;
//import org.example.automation.pepperfry.pages.HomePage;
//import org.example.automation.pepperfry.pages.SetteesBenchesPage;
//import org.example.automation.pepperfry.utils.ScreenshotUtils;
//import org.testng.annotations.Test;
//
//public class TC_Final_Flow extends BaseClass {
//
//    @Test
//    public void verifyMetalBenchesCount() throws Exception {
//        // 1. Initialize Page
//        HomePage home = new HomePage(driver);
//
//        // 2. Navigate (Popup is handled inside)
//        home.goToSetteesAndBenches();
//
//        SetteesBenchesPage page = new SetteesBenchesPage(driver);
//
//        // 3. Print Initial Counts
//        System.out.println("=== Initial Counts ===");
//        System.out.println("Benches: " + page.getBenchesCount());
//        System.out.println("Settees: " + page.getSetteesCount());
//        System.out.println("Recamiers: " + page.getRecamiersCount());
//
//        // 4. Apply Filter (Metal)
//        page.filterMetalBenches();
//
//        // 5. Get Filtered Count
//        int metalCount = page.getVisibleProductsCount();
//        System.out.println("=== After Filter: Metal ===");
//        System.out.println("Metal Benches Visible: " + metalCount);
//
//        // 6. Screenshot
//        ScreenshotUtils.takeScreenshot(driver, "Metal_Benches_Final");
//    }
//}