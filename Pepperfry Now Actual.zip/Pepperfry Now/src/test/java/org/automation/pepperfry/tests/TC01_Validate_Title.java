package org.automation.pepperfry.tests;

import org.example.automation.pepperfry.base.BaseClass;
import org.example.automation.pepperfry.pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC01_Validate_Title extends BaseClass {

    @Test
    public void validateTitle() {
        HomePage home = new HomePage(driver);
        String title = home.getTitle();
        System.out.println("Page Title: " + title);

        Assert.assertTrue(title.contains("Furniture") || title.contains("Shopping"),
                "Title validation failed!");
    }
}