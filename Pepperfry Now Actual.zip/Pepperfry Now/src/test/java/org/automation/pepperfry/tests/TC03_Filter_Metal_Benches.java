package org.automation.pepperfry.tests;

import org.example.automation.pepperfry.base.BaseClass;
import org.example.automation.pepperfry.pages.HomePage;
import org.example.automation.pepperfry.pages.SetteesBenchesPage;
import org.testng.annotations.Test;

public class TC03_Filter_Metal_Benches extends BaseClass {

    @Test
    public void filterMetal() {
        HomePage home = new HomePage(driver);
        home.goToSetteesAndBenches(); // Navigate again (fresh browser session)

        SetteesBenchesPage page = new SetteesBenchesPage(driver);
        page.filterMetalBenches();

        int count = page.getVisibleProductsCount();
        System.out.println("=== Filter Results ===");
        System.out.println("Metal Benches Visible: " + count);
    }
}