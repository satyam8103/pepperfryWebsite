package org.automation.pepperfry.tests;

import org.example.automation.pepperfry.base.BaseClass;
import org.example.automation.pepperfry.pages.HomePage;
import org.example.automation.pepperfry.pages.SetteesBenchesPage;
import org.testng.annotations.Test;

public class TC02_Count_Furniture extends BaseClass {

    @Test
    public void countFurniture() throws InterruptedException {
        HomePage home = new HomePage(driver);
        home.goToSetteesAndBenches();

        SetteesBenchesPage page = new SetteesBenchesPage(driver);

        System.out.println("=== Furniture Category Counts ===");
        System.out.println("Benches Count: " + page.getBenchesCount());
        System.out.println("Settees Count: " + page.getSetteesCount());
        System.out.println("Recamiers Count: " + page.getRecamiersCount());
    }
}