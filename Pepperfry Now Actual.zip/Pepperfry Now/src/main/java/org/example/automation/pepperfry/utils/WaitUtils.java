package org.example.automation.pepperfry.utils;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.function.Function;

public class WaitUtils {
    private WebDriver driver;
    private WebDriverWait wait;
    private FluentWait<WebDriver> fluentWait;

    public WaitUtils(WebDriver driver) {
        this.driver = driver;
        int explicitWait = ConfigReader.getExplicitWait();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(explicitWait));
        this.fluentWait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(explicitWait))
                .pollingEvery(Duration.ofMillis(500))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class)
                .ignoring(ElementClickInterceptedException.class);
    }

    /**
     * Wait for element to be visible
     */
    public WebElement waitForElementVisible(By locator) {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
            throw new TimeoutException("Element not visible within timeout: " + locator, e);
        }
    }

    /**
     * Wait for element to be clickable
     */
    public WebElement waitForElementClickable(By locator) {
        try {
            return wait.until(ExpectedConditions.elementToBeClickable(locator));
        } catch (TimeoutException e) {
            throw new TimeoutException("Element not clickable within timeout: " + locator, e);
        }
    }

    /**
     * Wait for element to be present in DOM
     */
    public WebElement waitForElementPresent(By locator) {
        try {
            return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
        } catch (TimeoutException e) {
            throw new TimeoutException("Element not present in DOM within timeout: " + locator, e);
        }
    }

    /**
     * Wait for element to be invisible
     */
    public boolean waitForElementInvisible(By locator) {
        try {
            return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
            return false;
        }
    }

    /**
     * Wait for all elements to be visible
     */
    public List<WebElement> waitForAllElementsVisible(By locator) {
        try {
            return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
        } catch (TimeoutException e) {
            throw new TimeoutException("Elements not visible within timeout: " + locator, e);
        }
    }

    /**
     * Wait for page to load completely
     */
    public void waitForPageLoad() {
        try {
            wait.until((Function<WebDriver, Boolean>) driver -> {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                return js.executeScript("return document.readyState").equals("complete");
            });
        } catch (TimeoutException e) {
            System.out.println("Page did not load completely within timeout");
        }
    }

    /**
     * Wait for JavaScript to complete
     */
    public void waitForJQueryLoad() {
        try {
            wait.until((Function<WebDriver, Boolean>) driver -> {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                return (Boolean) js.executeScript("return jQuery.active == 0");
            });
        } catch (Exception e) {
            // jQuery might not be present, ignore
        }
    }

    /**
     * Wait for Angular to complete
     */
    public void waitForAngularLoad() {
        try {
            wait.until((Function<WebDriver, Boolean>) driver -> {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                return (Boolean) js.executeScript("return angular.element(document).injector().get('$http').pendingRequests.length === 0");
            });
        } catch (Exception e) {
            // Angular might not be present, ignore
        }
    }

    /**
     * Wait with custom condition
     */
    public <T> T waitForCondition(Function<WebDriver, T> condition) {
        return fluentWait.until(condition);
    }

    /**
     * Wait for element to be stale (useful for dynamic content)
     */
    public boolean waitForElementStale(WebElement element) {
        try {
            return wait.until(ExpectedConditions.stalenessOf(element));
        } catch (TimeoutException e) {
            return false;
        }
    }

    /**
     * Wait for frame to be available and switch to it
     */
    public WebDriver waitForFrameAndSwitch(By frameLocator) {
        try {
            return wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameLocator));
        } catch (TimeoutException e) {
            throw new TimeoutException("Frame not available within timeout: " + frameLocator, e);
        }
    }

    /**
     * Wait for alert to be present
     */
    public Alert waitForAlert() {
        try {
            return wait.until(ExpectedConditions.alertIsPresent());
        } catch (TimeoutException e) {
            throw new TimeoutException("Alert not present within timeout", e);
        }
    }

    /**
     * Wait for text to be present in element
     */
    public boolean waitForTextInElement(By locator, String text) {
        try {
            return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
        } catch (TimeoutException e) {
            return false;
        }
    }

    /**
     * Wait for element with retry mechanism
     */
    public WebElement waitForElementWithRetry(By locator, int maxRetries) {
        WebElement element = null;
        for (int i = 0; i < maxRetries; i++) {
            try {
                element = waitForElementClickable(locator);
                break;
            } catch (Exception e) {
                if (i == maxRetries - 1) {
                    throw e;
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
        return element;
    }
}
