package org.example.automation.pepperfry.base;

import org.example.automation.pepperfry.utils.ConfigReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;
import java.util.Arrays;

public class BaseClass {

    protected WebDriver driver;

    @BeforeMethod
    public void setUp() {
        String browser = ConfigReader.getBrowser();
        System.out.println("Initializing browser: " + browser);

        try {
            if (browser.equalsIgnoreCase("firefox")) {
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                firefoxOptions.addArguments("--disable-notifications");
                driver = new FirefoxDriver(firefoxOptions);
            } else if (browser.equalsIgnoreCase("edge")) {
                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.addArguments("--disable-notifications");
                edgeOptions.setExperimentalOption("excludeSwitches", Arrays.asList("enable-automation"));
                edgeOptions.addArguments("--disable-extensions");
                edgeOptions.addArguments("--start-maximized");
                driver = new EdgeDriver(edgeOptions);
            } else {
                // Chrome Options setup to block popups
                ChromeOptions options = new ChromeOptions();

                // 1. Notification Allow/Block popup ko disable karta hai
                options.addArguments("--disable-notifications");

                // 2. Automation control bar (Chrome is being controlled by...) ko hide karta hai
                options.setExperimentalOption("excludeSwitches", Arrays.asList("enable-automation"));

                // 3. Browser extensions ko disable karta hai (jo ads la sakte hain)
                options.addArguments("--disable-extensions");

                // 4. Window maximize arguments
                options.addArguments("--start-maximized");

                // Initialize driver with options
                driver = new ChromeDriver(options);
            }

            // Implicit wait har element ke liye
            int implicitWait = ConfigReader.getImplicitWait();
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(implicitWait));

            // Page load timeout
            int pageLoadWait = ConfigReader.getPageLoadWait();
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(pageLoadWait));

            // Maximize window
            driver.manage().window().maximize();

            // URL Open
            String url = ConfigReader.getUrl();
            driver.get(url);
            System.out.println("Browser initialized successfully and navigated to: " + url);

        } catch (Exception e) {
            System.err.println("Error initializing browser: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize browser", e);
        }
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            try {
                // Close all windows quickly
                driver.quit();
                System.out.println("Browser closed successfully");
            } catch (Exception e) {
                // Try close() if quit() fails
                try {
                    driver.close();
                } catch (Exception ex) {
                    // Ignore if both fail
                }
            }
        }
    }
}