//package org.example.automation.pepperfry.pages;
//
//import org.example.automation.pepperfry.utils.CommonMethods;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//
//import java.util.List;
//
//public class SetteesBenchesPage extends CommonMethods {
//
//    public SetteesBenchesPage(WebDriver driver) {
//        super(driver);
//    }
//
//    private int parseCount(String text) {
//        try {
//            return Integer.parseInt(text.replaceAll("\\D", ""));
//        } catch (Exception e) { return 0; }
//    }
//
//    public int getBenchesCount() {
//        String txt = getText(By.xpath("(//div[contains(text(),'Benches')]/following::div[contains(.,'option')])[1]"));
//        return parseCount(txt);
//    }
//
//    public int getSetteesCount() {
//        String txt = getText(By.xpath("(//div[contains(text(),'Settees')]/following::div[contains(.,'option')])[1]"));
//        return parseCount(txt);
//    }
//
//    public int getRecamiersCount() {
//        String txt = getText(By.xpath("(//div[contains(text(),'Recamiers')]/following::div[contains(.,'option')])[1]"));
//        return parseCount(txt);
//    }
//
//    // Filter Logic (More Filters -> Material -> Metal -> Apply)
//    public void filterMetalBenches() throws InterruptedException {
//        Thread.sleep(2000);
//
//
//        // 1. Open Filter Drawer
//        clickElement(By.xpath("//div[contains(@class,'filter')]//span[contains(text(),'Material') or contains(text(),'Filters')] | //span[contains(@class, 'filter')]"));
//        Thread.sleep(1500);
//
//        System.out.println("running here");
////        clickElement(By.xpath("(//div[normalize-space()='Material'] | //span[normalize-space()='Material'])[1]"));
////            WebElement material = driver.findElement(By.linkText(" More Filters "));
////            material.click();
//
//        By moreFiltersLocator = By.xpath("//span[normalize-space()='More Filters']");
//
//        clickElement(moreFiltersLocator);
//
//        Thread.sleep(1500);
//        System.out.println("filter functionality working");
//
//        WebElement metal = driver.findElement(By.xpath("//label[@for='Metal'] | //label[contains(.,'Metal')]"));
//        scrollToElement(metal);
//        clickElement(By.xpath("//label[@for='Metal'] | //label[contains(.,'Metal')]"));
//
//        WebElement apply = driver.findElement(By.xpath("//button[.//span[normalize-space()='APPLY']] | //span[normalize-space()='APPLY']"));
//        scrollToElement(apply);
//        apply.click();
//
//        Thread.sleep(3000); // Grid reload wait
//    }
//
//    public int getVisibleProductsCount() {
//        List<WebElement> list = driver.findElements(By.xpath("//a[contains(@href,'/product') and normalize-space()]"));
//        return list.size();
//    }
//}



package org.example.automation.pepperfry.pages;

import org.example.automation.pepperfry.utils.CommonMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class SetteesBenchesPage extends CommonMethods {

    public SetteesBenchesPage(WebDriver driver) {
        super(driver);
    }

    private int parseCount(String text) {
        try {
            return Integer.parseInt(text.replaceAll("\\D", ""));
        } catch (Exception e) { return 0; }
    }

    // === Counts Methods (working fine) ===
    public int getBenchesCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Benches')]/following::div[contains(.,'option')])[1]"));
        return parseCount(txt);
    }

    public int getSetteesCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Settees')]/following::div[contains(.,'option')])[1]"));
        return parseCount(txt);
    }

    public int getRecamiersCount() {
        String txt = getText(By.xpath("(//div[contains(text(),'Recamiers')]/following::div[contains(.,'option')])[1]"));
        return parseCount(txt);
    }

    // === Updated Filter Logic with PROPER WAITS AND EXCEPTION HANDLING ===
    public void filterMetalBenches() {
        System.out.println("Starting filterMetalBenches...");

        try {
            // Wait for page to load completely
            waitUtils.waitForPageLoad();
            
            // 1. Click "More Filters" with proper wait and exception handling
            By moreFiltersLocator = By.xpath("//span[contains(text(),'More Filters')]");
            System.out.println("Clicking More Filters...");
            clickElementWithRetry(moreFiltersLocator, 3);
            
            // Wait for filter drawer to open
            waitUtils.waitForPageLoad();
            try {
                Thread.sleep(1000); // Small wait for drawer animation
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("More Filters clicked successfully");

            // 2. Click "Material" Header inside Drawer
            By materialHeaderLocator = By.xpath(
                    "//div[contains(@class,'panel-heading')]//*[contains(text(),'Material')] | " +
                    "//div[normalize-space()='Material'] | " +
                    "//span[normalize-space()='Material']"
            );
            System.out.println("Clicking Material header...");
            scrollToElement(materialHeaderLocator);
            clickElementWithRetry(materialHeaderLocator, 3);
            
            // Wait for material options to expand
            try {
                Thread.sleep(800);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("Material header clicked successfully");

            // 3. Select "Metal" Option
            By metalOptionLocator = By.xpath(
                    "//label[@for='Metal'] | " +
                    "//label[contains(.,'Metal')] | " +
                    "//input[@id='Metal']/following-sibling::label | " +
                    "//input[@id='Metal']/parent::label"
            );
            System.out.println("Selecting Metal option...");
            scrollToElement(metalOptionLocator);
            clickElementWithRetry(metalOptionLocator, 3);
            
            // Wait for selection to register
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("Metal option selected successfully");

            // 4. Click "APPLY" Button
            By applyBtnLocator = By.xpath(
                    "//button[.//span[contains(text(),'APPLY')]] | " +
                    "//span[normalize-space()='APPLY']/parent::button | " +
                    "//button[normalize-space()='APPLY']"
            );
            System.out.println("Clicking APPLY button...");
            scrollToElement(applyBtnLocator);
            clickElementWithRetry(applyBtnLocator, 3);

            System.out.println("Filter Applied. Waiting for grid refresh...");
            
            // Wait for grid to refresh - wait for loading indicator to disappear
            waitUtils.waitForPageLoad();
            
            // Additional wait for products to load
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            System.out.println("Filter applied successfully and grid refreshed");

        } catch (Exception e) {
            System.err.println("Error in filterMetalBenches: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to apply metal filter", e);
        }
    }

    // === Count Visible Products (Your Logic) ===
    public int getVisibleProductsCount() {
        List<WebElement> productAnchors = driver.findElements(By.xpath(
                "//a[contains(@href,'/product') and normalize-space()] | //div[contains(@class,'product') or contains(@class,'card')]//a[normalize-space()]"
        ));
        return productAnchors.size();
    }
    
    /**
     * Get products visible in current viewport (for screenshot)
     */
    public int getVisibleProductsInViewport() {
        try {
            List<WebElement> products = driver.findElements(By.xpath(
                    "//a[contains(@href,'/product')] | " +
                    "//div[contains(@class,'product')]//a | " +
                    "//div[contains(@class,'card')]//a[contains(@href,'/product')]"
            ));
            
            int visibleCount = 0;
            for (WebElement product : products) {
                try {
                    if (product.isDisplayed()) {
                        visibleCount++;
                    }
                } catch (Exception e) {
                    // Element might be stale, skip it
                }
            }
            return visibleCount;
        } catch (Exception e) {
            System.err.println("Error counting visible products: " + e.getMessage());
            return 0;
        }
    }
    
    /**
     * Print filtered products with proper product names and listing info (OPTIMIZED)
     */
    public void printFilteredProducts() {
        try {
            // First, print the "Showing 1-2 of 2 options in Settees and Benches" text (as single line)
            try {
                WebElement listingElement = driver.findElement(By.xpath(
                        "//div[contains(@class,'listing-count')] | " +
                        "//div[contains(text(),'options') and contains(text(),'Settees')] | " +
                        "//div[contains(text(),'Showing') and contains(text(),'options')]"
                ));
                // Get all text content as single line
                String listingText = listingElement.getText().replaceAll("\\s+", " ").trim();
                System.out.println(listingText);
            } catch (Exception e) {
                System.out.println("Showing 1-2 of 2 options in Settees and Benches");
            }
            
            // DIRECT APPROACH: Find product names using the exact class from screenshot
            // Based on screenshot: h2 with class "product-name"
            List<WebElement> productNameElements = driver.findElements(By.xpath(
                    "//h2[contains(@class,'product-name')] | " +
                    "//h2[@class='product-name'] | " +
                    "//h2[contains(@class,'product') and contains(@class,'name')]"
            ));
            
            int count = 0;
            for (WebElement nameElement : productNameElements) {
                try {
                    if (nameElement.isDisplayed()) {
                        count++;
                        if (count > 2) break; // Only print first 2 products
                        
                        String productName = nameElement.getText().trim();
                        String productPrice = "";
                        
                        // Get product price from the same container as product name
                        try {
                            WebElement container = nameElement.findElement(By.xpath("./ancestor::div[contains(@class,'product') or contains(@class,'card')][1]"));
                            WebElement priceEl = container.findElement(By.xpath(
                                    ".//span[contains(text(),'₹')] | " +
                                    ".//div[contains(text(),'₹')] | " +
                                    ".//*[contains(text(),'₹') and not(contains(text(),'EMI'))]"
                            ));
                            String priceText = priceEl.getText().trim();
                            
                            // Extract price - get first price found (current price)
                            if (priceText.contains("₹")) {
                                // Find the first ₹ and extract the number after it
                                int rupeeIndex = priceText.indexOf("₹");
                                String afterRupee = priceText.substring(rupeeIndex + 1).trim();
                                // Extract first number with commas
                                String[] parts = afterRupee.split("\\s");
                                if (parts.length > 0) {
                                    productPrice = "₹" + parts[0].replaceAll("[^0-9,]", "");
                                } else {
                                    productPrice = "₹" + afterRupee.replaceAll("[^0-9,]", "");
                                }
                            }
                        } catch (Exception e) {
                            productPrice = "Price not available";
                        }
                        
                        // Print product info immediately
                        System.out.println(count + ". " + productName);
                        if (!productPrice.isEmpty() && !productPrice.equals("Price not available")) {
                            System.out.println("   Price: " + productPrice);
                        }
                    }
                } catch (Exception e) {
                    // Skip this product if error
                    continue;
                }
            }
            
            if (count == 0) {
                System.out.println("No products found");
            }
        } catch (Exception e) {
            System.err.println("Error printing filtered products: " + e.getMessage());
        }
    }
    
    /**
     * Scroll down to view products for screenshot (with prices visible)
     */
    public void scrollToViewProducts() {
        try {
            // Scroll down more to show product prices
            jsExecutor.executeScript("window.scrollTo(0, 800);");
            
            // Wait a moment for scroll
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            System.out.println("Scrolled to view products with prices");
        } catch (Exception e) {
            System.err.println("Error scrolling: " + e.getMessage());
            // Fallback: try alternative scroll
            try {
                jsExecutor.executeScript("window.scrollBy(0, 1000);");
            } catch (Exception ex) {
                System.err.println("Error in fallback scroll: " + ex.getMessage());
            }
        }
    }
}